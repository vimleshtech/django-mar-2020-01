# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse
import mysql.connector as c
# Create your views here.
def index(request):
    #return HttpResponse('<h1> hello this this is test web app </h1>')
    return render(request,'dashboard/index.html')

def register(request):
    name = request.GET['name']
    email = request.GET['email']
    pwd = request.GET['pwd']
    age = request.GET['age']

    #db connection 
    con = c.connect(host='',database='',user='',password='')
    cur = con.cursor()
    cur.execute(select * from user)
    data = cur.fatchall()
    print(data)
    
    return HttpResponse('<h1>get request ' + name +'</h1>')
