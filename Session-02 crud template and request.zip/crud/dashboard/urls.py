
from django.conf.urls import url,include
from . import views


urlpatterns = [

 
 
    url('register', views.register,name="register"),
    url('', views.index,name="index")
    
]
